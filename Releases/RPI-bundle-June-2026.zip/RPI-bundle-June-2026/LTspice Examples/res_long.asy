Version 4
SymbolType CELL
LINE Normal 16 48 16 128
LINE Normal 16 -128 16 -48
RECTANGLE Normal 24 48 7 -48
WINDOW 0 32 -16 Left 2
WINDOW 3 32 16 Left 2
SYMATTR Value R
SYMATTR Prefix R
SYMATTR Description A resistor
PIN 16 -128 NONE 0
PINATTR PinName A
PINATTR SpiceOrder 1
PIN 16 128 NONE 0
PINATTR PinName B
PINATTR SpiceOrder 2
