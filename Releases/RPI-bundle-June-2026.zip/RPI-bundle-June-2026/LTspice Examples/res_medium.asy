Version 4
SymbolType CELL
LINE Normal 16 32 16 96
LINE Normal 16 -96 16 -32
RECTANGLE Normal 24 32 7 -32
WINDOW 0 32 -16 Left 2
WINDOW 3 32 16 Left 2
SYMATTR Value R
SYMATTR Prefix R
SYMATTR Description A resistor
PIN 16 -96 NONE 0
PINATTR PinName A
PINATTR SpiceOrder 1
PIN 16 96 NONE 0
PINATTR PinName B
PINATTR SpiceOrder 2
